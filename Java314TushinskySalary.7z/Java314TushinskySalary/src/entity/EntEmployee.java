/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Sergii.Tushinskyi
 */
public class EntEmployee {
    private final String name;
    private EntSalary salary;
    public EntEmployee(String name) {
        this.name = name;
    }

    public EntEmployee(String name, EntSalary salary) {
        this.name = name;
        this.salary = salary;
    }

    public EntSalary getSalary() {
        return salary;
    }

    public void setSalary(EntSalary salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "EntEmployee{" + "name=" + name +
                ", salary=" + salary.toString() + '}';
    }
    
}
